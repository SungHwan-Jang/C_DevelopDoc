#ifndef BANK_ACCOUNT_H
#define BANK_ACCOUNT_H

void deposit_into_chequing(const unsigned int amount);
void deposit_into_saving(const unsigned int amount);

#endif /* BANK_ACCOUNT_H */
