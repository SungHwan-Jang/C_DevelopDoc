#ifndef WALLET_H
#define WALLET_H

void deposit(unsigned int dollars, unsigned int cents);
void withdraw(unsigned int dollars, unsigned int cents);

#endif /* WALLET_H */
