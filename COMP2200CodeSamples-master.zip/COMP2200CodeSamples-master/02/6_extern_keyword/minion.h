#ifndef MINION_H
#define MINION_H
    
void go_berserk(void);
void add_gold(unsigned int gold);

#endif /* MINION_H */
