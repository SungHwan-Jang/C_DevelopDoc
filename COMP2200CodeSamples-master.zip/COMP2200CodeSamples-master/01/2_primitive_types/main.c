#include <stdio.h>

int main(void)
{
    int int_value = 10;
    long long_value = 100;
    float float_value = 1.5f;
    char char_value = 'A';

    printf("int_value: %d\n", int_value);
    printf("long_value: %ld\n", long_value);
    printf("float_value: %f\n", float_value);
    printf("char_value: %c\n", char_value);

    return 0;
}
