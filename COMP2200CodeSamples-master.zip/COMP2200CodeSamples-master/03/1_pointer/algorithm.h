#ifndef ALGORITHM_H
#define ALGORITHM_H

void get_min_max(const int nums[], const size_t length, int* out_min, int* out_max);

#endif /* ALGORITHM_H */
