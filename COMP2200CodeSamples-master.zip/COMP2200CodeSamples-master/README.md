# COMP2200 C Code Samples
C sample codes for COMP2200 course offered at POCU(https://pocu.academy)

Web-based presentation with annotation is also available for enrolled users as well
