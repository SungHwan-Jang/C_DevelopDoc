#ifndef STRING_UTILS_H
#define STRING_UTILS_H

int string_case_insensitive_compare(const char* str0, const char* str1);

#endif /* STRING_UTILS_H */
