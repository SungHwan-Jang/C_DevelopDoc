#ifndef BUFFERED_PRINT_H
#define BUFFERED_PRINT_H

void buffered_print(const char* src);

#endif /* BUFFERED_PRINT_H */
