#ifndef PRINT_ASCII_TABLE_H
#define PRINT_ASCII_TABLE_H

void print_ascii_table(void);

#endif /* PRINT_ASCII_TABLE_H */
