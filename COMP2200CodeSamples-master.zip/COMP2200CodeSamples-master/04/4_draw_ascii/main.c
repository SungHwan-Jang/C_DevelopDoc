#include "print_ascii_table.h"

int main(void)
{
    print_ascii_table();

    return 0;
}
