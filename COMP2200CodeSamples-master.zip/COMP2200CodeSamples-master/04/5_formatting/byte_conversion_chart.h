#ifndef PRINT_DATA_UNITS_H
#define PRINT_DATA_UNITS_H

void print_byte_conversion_chart(void);
void print_byte_conversion_chart_scientific(void);

#endif /* PRINT_DATA_UNITS_H */
