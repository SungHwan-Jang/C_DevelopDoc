#include <stdio.h>

#include "byte_conversion_chart.h"

int main(void)
{
    print_byte_conversion_chart();

    printf("\n");

    print_byte_conversion_chart_scientific();

    return 0;
}
