#ifndef SIMPLEIO_H
#define SIMPLEIO_H

void printf_simple(const char* format, ...);

#endif /* SIMPLEIO_H */
