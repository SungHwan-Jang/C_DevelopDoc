#ifndef ADDER_H
#define ADDER_H

void run_adder(void);

#endif
