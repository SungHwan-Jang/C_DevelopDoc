#ifndef STATIC_MATH_H
#define STATIC_MATH_H

static inline int static_add(int a, int b)
{
    return a + b;
}

#endif /* STATIC_MATH_H */
