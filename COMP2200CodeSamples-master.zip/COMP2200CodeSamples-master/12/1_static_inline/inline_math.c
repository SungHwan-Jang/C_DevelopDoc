#include "inline_math.h"

extern inline int inline_add(int a, int b);
