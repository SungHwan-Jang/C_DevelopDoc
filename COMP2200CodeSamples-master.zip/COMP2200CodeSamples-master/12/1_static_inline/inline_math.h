#ifndef INLINE_MATH_H
#define INLINE_MATH_H

inline int inline_add(int a, int b)
{
    return a + b;
}

#endif /* INLINE_MATH_H */
