#ifndef FILE_UTILS_H
#define FILE_UTILS_H

void copy_file(const char* src, const char* dst);

#endif /* FILE_UTILS_H */
