#include "file_utils.h"

int main(void)
{
    copy_file("src.txt", "copy.txt");
    return 0;
}
