#ifndef FILE_UTILS_H
#define FILE_UTILS_H

void print_with_repeats(const char* filename);

#endif /* FILE_UTILS_H */
