#include "file_utils.h"

int main(void)
{
    print_with_repeats("text.txt");

    return 0;
}
