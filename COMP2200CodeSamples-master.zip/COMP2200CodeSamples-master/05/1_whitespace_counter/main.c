#include "whitespace_counter.h"

int main(void)
{
    print_whitespace_stat();

    return 0;
}
