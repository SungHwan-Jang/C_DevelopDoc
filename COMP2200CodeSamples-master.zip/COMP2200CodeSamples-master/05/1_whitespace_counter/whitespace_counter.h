#ifndef WHITESPACE_COUNTER_H
#define WHITESPACE_COUNTER_H

void print_whitespace_stat(void);

#endif /* WHITESPACE_COUNTER_H */
