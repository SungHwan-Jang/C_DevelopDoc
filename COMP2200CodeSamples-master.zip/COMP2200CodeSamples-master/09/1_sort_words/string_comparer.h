#ifndef STRING_COMPARER_H
#define STRING_COMPARER_H

int compare_string(const void* a, const void* b);
int compare_string_desc(const void* a, const void* b);

#endif /* STRING_COMPARER_H */
