#ifndef USER_SORTER_H
#define USER_SORTER_H

int compare_age_id(const void* p0, const void* p1);
int compare_age_desc_sex(const void* p0, const void* p1);

#endif /* USER_SORTER_H */
